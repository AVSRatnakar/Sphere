# ENV Variables

EXPO_PUBLIC_apiKey=
EXPO_PUBLIC_authDomain=
EXPO_PUBLIC_databaseURL=
EXPO_PUBLIC_projectId=
EXPO_PUBLIC_storageBucket=
EXPO_PUBLIC_messagingSenderId=
EXPO_PUBLIC_appId=
EXPO_PUBLIC_measurementId=

EXPO_PUBLIC_IosClientId=
EXPO_PUBLIC_AndroidClientId=
EXPO_PUBLIC_ExpoClientId=

EXPO_PUBLIC_API_URL=https://staging.example.com
EXPO_PUBLIC_API_KEY=abc123
