export const defaultCommunities = [
	{
		name: 'Classroom',
		id: 'classroom',
	},
	{
		name: 'Training and Placement',
		id: 'training',
	},
	{
		name: 'Exam Corner',
		id: 'exam',
	},
];
